FMA - SNOMED
----------------

- Reference UMLS-based mappings:
	Total mappings 9,008
	6,026 mappings "="
	2,982 mappings flagged with "?" (mapping involved in logical conflicts detected by Alcomo, LogMap and/or AML)

- FMA ontology (contains synonyms):
	- Whole ontology: 78,989 concepts
	- Small overlapping/module with SNOMED:  10,157 concepts (13%)

- SNOMED ontology (contains synonyms):
	- Big overlapping/module with FMA and NCI:    122,464 classes (40%) 
	- Small overlapping/module with FMA:  13,412 concepts (5%)


